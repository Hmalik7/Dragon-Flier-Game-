// eggStage -- to represent the different stages of the egg
enum eggStage {
    NONEXISTENT,
    NOTREADYTOEAT,
    READYTOEAT,
    HATCHED,
    KILLED,
    EATEN
}